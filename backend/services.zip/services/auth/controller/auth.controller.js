import { getAuth } from "firebase-admin/auth";
import { app } from "../config/firebase.js";
import { get } from "mongoose";
import User from "../models/user.model.js";
import redis from "../../../shared/redis.js";

export const login = async (req, res) =>{
    try{
     const{token} = req.body;
      const decodedToken = await getAuth(app).verifyIdToken(token);

   let user = await User.findOne({ firebaseUId: decodedToken.uid });

      if(!user){
         user = await User.create({
            firebaseUId: decodedToken.uid,
            name: decodedToken.name,
            email: decodedToken.email,
            avatar: decodedToken.picture
        });
      
      }
       //storing session in cookie
      const sessionId = crypto.randomUUID();
      redis

      res.cookie("session", sessionId, {
        httpOnly: true,
        secure: true,
        sameSite: "strict",
        maxAge: 24 * 60 * 60 * 1000, // 1 day
      });
      return res.status(200).json({message: "Login successful cached"});
    }
    catch(error){
        res.status(500).json({message: "login error", error: error.message});
    }
}