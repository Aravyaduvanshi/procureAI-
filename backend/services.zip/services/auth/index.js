
import express from "express";
import dotenv from "dotenv";
import router from "./routes/auth.route.js";
import connectdb from "./config/db.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8001;

app.use(express.json());
app.use("/", router);

app.get("/", (req, res) => {
  res.json({ message: "Auth service is running" });
});

async function startServer() {
  try {
    await connectdb();

    app.listen(PORT, () => {
      console.log(`Auth service is running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start auth service:", error);
    process.exit(1);
  }
}

startServer();
